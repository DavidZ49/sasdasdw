@echo off
title OperacionesCRUD
java -jar OperacionesCRUD.jar
pause
